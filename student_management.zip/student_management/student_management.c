#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Student {
    int roll;
    char name[50];
    float marks;
    struct Student *next;
};

struct Student *head = NULL;

// Function Declarations
void addStudent();
void displayStudents();
void searchStudent();
void updateStudent();
void deleteStudent();
void saveToFile();
void loadFromFile();

// Main Function
int main() {
    int choice;

    loadFromFile();

    do {
        printf("\n===== STUDENT MANAGEMENT SYSTEM =====\n");
        printf("1. Add Student\n");
        printf("2. Display Students\n");
        printf("3. Search Student\n");
        printf("4. Update Student\n");
        printf("5. Delete Student\n");
        printf("6. Save Data to File\n");
        printf("7. Load Data from File\n");
        printf("8. Exit\n");

        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch(choice) {
            case 1:
                addStudent();
                break;

            case 2:
                displayStudents();
                break;

            case 3:
                searchStudent();
                break;

            case 4:
                updateStudent();
                break;

            case 5:
                deleteStudent();
                break;

            case 6:
                saveToFile();
                break;

            case 7:
                loadFromFile();
                break;

            case 8:
                saveToFile();
                printf("Exiting Program...\n");
                break;

            default:
                printf("Invalid Choice!\n");
        }

    } while(choice != 8);

    return 0;
}

// Add Student
void addStudent() {
    struct Student *newNode, *temp;

    newNode = (struct Student *)malloc(sizeof(struct Student));

    if(newNode == NULL) {
        printf("Memory Allocation Failed!\n");
        return;
    }

    printf("Enter Roll Number: ");
    scanf("%d", &newNode->roll);

    printf("Enter Name: ");
    scanf(" %[^\n]", newNode->name);

    printf("Enter Marks: ");
    scanf("%f", &newNode->marks);

    newNode->next = NULL;

    if(head == NULL) {
        head = newNode;
    } else {
        temp = head;

        while(temp->next != NULL) {
            temp = temp->next;
        }

        temp->next = newNode;
    }

    printf("Student Added Successfully!\n");
}

// Display Students
void displayStudents() {
    struct Student *temp = head;

    if(head == NULL) {
        printf("No Student Records Found!\n");
        return;
    }

    printf("\n===== STUDENT RECORDS =====\n");

    while(temp != NULL) {
        printf("\nRoll Number : %d\n", temp->roll);
        printf("Name        : %s\n", temp->name);
        printf("Marks       : %.2f\n", temp->marks);

        temp = temp->next;
    }
}

// Search Student
void searchStudent() {
    int roll, found = 0;
    struct Student *temp = head;

    printf("Enter Roll Number to Search: ");
    scanf("%d", &roll);

    while(temp != NULL) {
        if(temp->roll == roll) {
            printf("\nStudent Found!\n");
            printf("Roll Number : %d\n", temp->roll);
            printf("Name        : %s\n", temp->name);
            printf("Marks       : %.2f\n", temp->marks);

            found = 1;
            break;
        }

        temp = temp->next;
    }

    if(!found) {
        printf("Student Not Found!\n");
    }
}

// Update Student
void updateStudent() {
    int roll, found = 0;
    struct Student *temp = head;

    printf("Enter Roll Number to Update: ");
    scanf("%d", &roll);

    while(temp != NULL) {
        if(temp->roll == roll) {

            printf("Enter New Name: ");
            scanf(" %[^\n]", temp->name);

            printf("Enter New Marks: ");
            scanf("%f", &temp->marks);

            printf("Student Updated Successfully!\n");

            found = 1;
            break;
        }

        temp = temp->next;
    }

    if(!found) {
        printf("Student Not Found!\n");
    }
}

// Delete Student
void deleteStudent() {
    int roll;
    struct Student *temp = head;
    struct Student *prev = NULL;

    printf("Enter Roll Number to Delete: ");
    scanf("%d", &roll);

    while(temp != NULL && temp->roll != roll) {
        prev = temp;
        temp = temp->next;
    }

    if(temp == NULL) {
        printf("Student Not Found!\n");
        return;
    }

    if(prev == NULL) {
        head = temp->next;
    } else {
        prev->next = temp->next;
    }

    free(temp);

    printf("Student Deleted Successfully!\n");
}

// Save Data to File
void saveToFile() {
    FILE *fp;
    struct Student *temp = head;

    fp = fopen("students.txt", "w");

    if(fp == NULL) {
        printf("File Cannot Be Opened!\n");
        return;
    }

    while(temp != NULL) {
        fprintf(fp, "%d %s %.2f\n",
                temp->roll,
                temp->name,
                temp->marks);

        temp = temp->next;
    }

    fclose(fp);

    printf("Data Saved Successfully!\n");
}

// Load Data from File
void loadFromFile() {
    FILE *fp;
    struct Student *newNode, *temp;

    fp = fopen("students.txt", "r");

    if(fp == NULL) {
        return;
    }

    while(1) {

        newNode = (struct Student *)malloc(sizeof(struct Student));

        if(fscanf(fp, "%d %s %f",
                  &newNode->roll,
                  newNode->name,
                  &newNode->marks) != 3) {

            free(newNode);
            break;
        }

        newNode->next = NULL;

        if(head == NULL) {
            head = newNode;
        } else {
            temp = head;

            while(temp->next != NULL) {
                temp = temp->next;
            }

            temp->next = newNode;
        }
    }

    fclose(fp);
}
